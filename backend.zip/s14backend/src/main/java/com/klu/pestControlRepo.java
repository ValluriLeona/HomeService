package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface  pestControlRepo  extends JpaRepository<PestControl, Integer>{

}

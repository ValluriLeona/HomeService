package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CarpenterRepo  extends JpaRepository<Carpenter, Integer> {

}

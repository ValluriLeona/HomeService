package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BeautyProductRepo extends JpaRepository<BeautyProduct, Integer> {

}

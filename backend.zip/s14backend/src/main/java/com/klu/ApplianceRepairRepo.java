package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplianceRepairRepo extends JpaRepository<ApplianceRepair, Integer>{

}

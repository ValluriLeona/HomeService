package com.klu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MechanicalRepairRepo extends JpaRepository<MechanicalRepair, Integer> {

}
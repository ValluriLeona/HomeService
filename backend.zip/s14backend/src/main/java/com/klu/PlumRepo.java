package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PlumRepo  extends JpaRepository<Plumbing, Integer>{

}

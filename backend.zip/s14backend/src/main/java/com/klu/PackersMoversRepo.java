package com.klu;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PackersMoversRepo  extends JpaRepository<PackersMovers, Integer>
{
	}